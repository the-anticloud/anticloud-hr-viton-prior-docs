# OSINT Benchmark — HR_VITON

**Upstream:** https://github.com/sangyun884/HR-VITON

Public-record information collected about upstream project:

- GitHub stars: see upstream
- License: MIT
- Last commit: check upstream
- Known CVEs: check NVD

Status: PENDING systematic collection.
